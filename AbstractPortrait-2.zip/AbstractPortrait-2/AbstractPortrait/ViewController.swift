//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Abstract Portrait"
        
        // *******************************************************************
        // CHANGE THE SIZE OF THE VIEW
        // For this project, you will want to change the size
        // of the view to match the size of your source image. You
        // change that right here.
        makeView(width: 720.0, height: 700.0)
        
        
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

} // end of ViewController class


class Scene: TScene {
    
    var photo: TImage!
    
    
    override func setup() {
        // Add code to load the image here to do one time setup tasks.
        
        photo = TImage(contentsOfFileInBundle: "IMG_3115.jpeg")
        
        guard photo != nil else {
            fatalError("The source image did not load correctly, you must fix this problem to continue.")
        }
        
        // Load the pixel data, allows you to get individual pixel data.
        photo.loadPixels()
        
    } // end of setup method
    
    
    override func update() {
        background(gray: 0.0)
        
        // Code for your abstract portrait goes here
        
        // *******************************************************************
        // This instruction to photo.draw() is here for debugging/testing only
        // It lets you easily see that your image is really loaded, and its
        // the correct size. Please remove this line after you have tested
        // the image.
        strokeDisable()
        for _ in 1...100000 {
            let x = random(min: tin.midX, max: tin.width)
            let y = random(min: 0, max: tin.midY)
            let color = photo.color(atX: Int(x), y: Int(y))
            
            color.setFillColor()
            let luma = color.luminance()
            let w = remap(value: luma, start1: 0.0, stop1: 1.0, start2: 60.0, stop2: 5.0)
            let alpha = remap(value: luma, start1: 0.0, stop1: 1.0, start2: 0.1, stop2: 0.4)
            
            setAlpha(alpha)
            ellipse(centerX: x, centerY: y, width: w, height: w)
        }
        for _ in 1...100000 {
            let x = random(min: 0, max: tin.midX)
            let y = random(min: tin.midY, max: tin.height)
            let color = photo.color(atX: Int(x), y: Int(y))
            
            color.setFillColor()
            let luma = color.luminance()
            let w = remap(value: luma, start1: 0.0, stop1: 1.0, start2: 60.0, stop2: 5.0)
            let alpha = remap(value: luma, start1: 0.0, stop1: 1.0, start2: 0.1, stop2: 0.4)
            
            setAlpha(alpha)
            ellipse(centerX: x, centerY: y, width: w, height: w)
        }
       
        for _ in 1...100 {
            let width = 10.0
            var y = width / 2.0
            while y < tin.midY {
                
                var x = width / 2.0
                while x < tin.midX {
                    let color = photo.color(atX: Int(x), y: Int(y))
                    color.setFillColor()
                    rect(x: x - width/2.0, y: y - width/2.0, width: width, height: width)
                    
                    
                    x += width
                }
                
                y += width
            }
            
            
        }
        setAlpha(0.9)
        photo.draw(x: tin.midX, y: tin.midY, width: 400.0, height: 350.0)
        
        for _ in 1...1000 {
            let x = random(min: tin.midX + 30.0, max: 630.0)
            let y = random(min: tin.midY + 20.0, max: tin.height - 60.0)
            let color = photo.color(atX: Int(x), y: Int(y))
           
            color.setFillColor()
           
            let w = random(min: 5.0, max: 50.0)
            rect(x: x, y: y, width: w, height: w)
        }
    
       photo.draw(x: 90.0, y: 80.0, width: 160.0, height: 140.0)

            
            
        
       
            
            
        
       
        
        

        // stop updates - program isn't interactive
        view?.stopUpdates()
    } // end of update method
    
    
} // end of Scene class


