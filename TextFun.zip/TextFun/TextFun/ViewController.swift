//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {
    var scene: Scene!
    
    override func viewWillAppear() {
        view.window?.title = "Text Fun"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    //
    // press the s key to start the animation
    //
    override func keyUp(with event: NSEvent) {
        if event.characters == "s" {
            scene.startAnimation()
        }
        else if event.characters == "r" {
            scene.reset()
        }
    }

}


class Scene: TScene {
    
   
    var font1 = TFont(fontName: "Avenir Next Heavy", ofSize: 150.0)
    var font2 = TFont(fontName: "Brush Script MT Italic", ofSize: 170.0)
    
    
    var isAnimationRunning = false
    var stepper1 = AnimationStepper(length: 60)
    var stepper2 = AnimationStepper(length: 120)
    var stepper3 = AnimationStepper(length: 90)
    
    
    override func setup() {
        reset()
        stepper1.reset()
        stepper2.reset()
        stepper3.reset()
        
        
    } // end of setup function
    
    
    override func update() {
        background(red: 0.91, green: 0.49, blue: 0.33)
        
        
        pushState()
        let xValue1 = random(min: 0.0, max: tin.width)
        let yValue1 = random(min: 0.0, max: tin.height)
        let xValue2 = random(min: 0.0, max: tin.width)
        let yValue2 = random(min: 0.0, max: tin.height)
        for _ in 1...3 {
            
            
            strokeColor(red: 1.0, green: 0.0, blue: 0.0, alpha: 0.9)
            lineWidth(20.0)
            line(x1: xValue1, y1: yValue1, x2: xValue1 + 10.0, y2: yValue1 - 10.0)
           
            
        }
        
        for _ in 1...3 {
            fillColor(red: 0.0, green: 0.8, blue: 0.5, alpha: 0.9)
            strokeDisable()
            ellipse(centerX: xValue2, centerY: yValue2, width: 50.0, height: 50.0)
        }
        popState()

        
        
        
        if isAnimationRunning {
            animationStep()
        }

       
        // !!!! Creator Disclaimer: Just making fun of the meme, not meant to be taken seriously !!!!
        
        fillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        let time1 = stepper1.time()
        let time2 = stepper2.time()
        let time3 = stepper3.time()
       
        translate(dx: tin.midX + 100.0, dy: tin.height - 150.0)
//        rotate(by: Double.pi / 4.0)
       
        let startX1 = 600.0
        let endX1 = 0.0
        let x1 = easeOutQuad(value: time1, start: startX1, stop: endX1)
        
        pushState()
        translate(dx: x1, dy: 0.0)
        text(message: "Epstein", font: font1, x: 0.0, y: 0.0)
        popState()
        
        
        
        
        let startX2 = -550.0
        let endX2 = 130.0
        let x2 = easeOutQuad(value: time2, start: startX2, stop: endX2)
       
        pushState()
        rotate(by: -Double.pi/2.0)
        translate(dx: x2, dy: 0.0)
        text(message: "Didn't", font: font1, x: 0.0, y: -480.0)
        popState()
        
        pushState()
        let startX3 = 900.0
        let endX3 = -300.0
        let x3 = easeOutQuad(value: time3, start: startX3, stop: endX3)
        translate(dx: x3, dy: 0.0)
        rotate(by: Double.pi / 4.5)
        text(message: "Kill", font: font2, x: 0.0, y: -250.0)
        popState()
        
        pushState()
        let startX4 = 900.0
        let endX4 = -250.0
        let x4 = easeOutQuad(value: time3, start: startX4, stop: endX4)
        translate(dx: x4, dy: -125.0)
        rotate(by: Double.pi / 4.5)
        text(message: "Himself!", font: font2, x: 0.0, y: -220.0)
        popState()
        
        
        
        
        
        
        

    } // end of update function
    
    
    // Set the values for any variables to position
    // the text for the beginning of the animation.
    func reset() {
        stepper1.reset()
        stepper2.reset()
        stepper3.reset()
    }
    
    
    // Start the animation running
    func startAnimation() {
        isAnimationRunning = true
        
        // Add code to here to setup
        // any values for the start of the
        // animation.
        stepper1.reset()
        stepper2.reset()
        stepper3.reset()
        
    } // end of startAnimation function
    

    // Move the values forward one frame
    func animationStep() {
        // call step() for any AnimationStepper objects here
        stepper1.step()
        let time1 = stepper1.time()
        if time1 > 0.5 {
        if stepper2.step() == false {
            isAnimationRunning = false
        }
        }
        let time2 = stepper2.time()
        if time2 > 0.5 {
            if stepper3.step() == false {
                isAnimationRunning = false
        }
        }
        
        
        
    } // end of animationStep function
    
}

