//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Parallax"
        makeView(width: 1000.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

} // end of ViewController class


class Scene: TScene {
    // The ! after TImage is important here.
    // We don't create the TImage object until the setup function runs.
    var bird: TImage!
    var sky: TImage!
    var finn: TImage!
    var marcy: TImage!
    var treehouse: TImage!
    var logo: TImage!
    
    override func setup() {
        // The image must be added to the Xcode project.
        // The image also needs to be part of the "target membership"
        // of this application. Select the image, and look at the
        // File inspector to verify the membership.
        sky = TImage(contentsOfFileInBundle: "Moresky.png")
        finn = TImage(contentsOfFileInBundle: "pngguru.com.png")
        marcy = TImage(contentsOfFileInBundle: "pngfind.com-adventure-time-png-1073835.png")
        treehouse = TImage(contentsOfFileInBundle: "pngfind.com-treehouse-png-6807587.png")
        logo = TImage(contentsOfFileInBundle: "pngfind.com-adventure-time-png-715492.png")
        
        
        
        
    } // end of setup function
    
    
    override func update() {
        background(gray: 0.5)
        
        
      
        let finnX = remap(value: tin.mouseX, start1: 200.0, stop1: 1000.0, start2: 400.0, stop2: 1000.0)
        let marcyX = remap(value: tin.mouseX, start1: 0.0, stop1: 1000.0, start2: 0.0, stop2: 75.0)
        let heightX = remap(value: tin.mouseX, start1: 0.0, stop1: 1000.0, start2: 500.0, stop2: 650.0)
        let logoY = remap(value: tin.mouseX, start1: 0.0, stop1: 1000.0, start2: 600.0, stop2: 450.0)
//
        
        
        sky.draw(x: 0.0, y: 0.0)
        treehouse.draw(x: 200.0, y: -100.0, width: heightX, height: heightX)
        finn.draw(x: finnX, y: 100.0, width: 400.0, height: 400.0)
        marcy.draw(x: marcyX, y: 120.0, width: 250.0, height: 300.0)
        logo.draw(x: 50.0, y: logoY, width: 250.0, height: 100.0)
        
        
        
        
        
        
        
    } // end of update function
    
} // end of Scene class

